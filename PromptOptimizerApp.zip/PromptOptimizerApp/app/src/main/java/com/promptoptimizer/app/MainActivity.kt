package com.promptoptimizer.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.webkit.*
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast

/**
 * 提示词优化器 Android 客户端：
 * 用 WebView 承载在线版（所有功能与网页版完全一致，并自动获得更新）。
 * 数据（API 密钥、历史记录、模板）保存在应用内的 localStorage / IndexedDB 中。
 */
class MainActivity : Activity() {

    companion object {
        const val DEFAULT_URL = "https://prompt.always200.com/#/basic/system"
        const val PREFS = "settings"
        const val KEY_URL = "server_url"
        const val REQ_FILE = 1001
    }

    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val serverUrl: String
        get() = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8)
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage（保存密钥/历史）
            databaseEnabled = true            // IndexedDB
            allowFileAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString + " PromptOptimizerApp/1.0"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = Uri.parse(serverUrl).host
                if (uri.scheme == "blob" || uri.host == host) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                } catch (e: Exception) { true }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                progress.visibility = android.view.View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = android.view.View.GONE
                CookieManager.getInstance().flush()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }

            // 文件选择：导入数据、图生图上传图片等
            override fun onShowFileChooser(
                wv: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    startActivityForResult(params.createIntent(), REQ_FILE); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        // 导出文件下载（blob: 与普通链接）
        webView.setDownloadListener { url, ua, disposition, mime, _ ->
            val name = URLUtil.guessFileName(url, disposition, mime)
            if (url.startsWith("blob:")) {
                val js = """
                    (async function(){
                      try {
                        const r = await fetch('$url'); const b = await r.blob();
                        const fr = new FileReader();
                        fr.onloadend = function(){ AndroidBridge.saveFile(fr.result, '${mime ?: "application/octet-stream"}', '${name.replace("'", "")}'); };
                        fr.readAsDataURL(b);
                      } catch(e) { AndroidBridge.toast('导出失败: ' + e); }
                    })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            } else {
                val req = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mime)
                    addRequestHeader("User-Agent", ua)
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast("开始下载: $name")
            }
        }

        if (savedInstanceState == null) webView.loadUrl(serverUrl) else webView.restoreState(savedInstanceState)
    }

    inner class Bridge {
        @JavascriptInterface
        fun toast(msg: String) = runOnUiThread { this@MainActivity.toast(msg) }

        @JavascriptInterface
        fun saveFile(dataUrl: String, mime: String, name: String) {
            try {
                val bytes = Base64.decode(dataUrl.substringAfter(","), Base64.DEFAULT)
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("无法创建文件")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                runOnUiThread { toast("已保存到“下载”文件夹: $name") }
            } catch (e: Exception) {
                runOnUiThread { toast("保存失败: ${e.message}") }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    // ---- 菜单：刷新 / 服务器地址 / 清除缓存 ----
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "刷新")
        menu.add(0, 2, 1, "服务器地址（自部署）")
        menu.add(0, 3, 2, "恢复默认地址")
        menu.add(0, 4, 3, "清除缓存")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> webView.reload()
            2 -> showUrlDialog()
            3 -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_URL).apply()
                webView.loadUrl(DEFAULT_URL)
            }
            4 -> { webView.clearCache(true); toast("缓存已清除（密钥与历史记录不受影响）") }
        }
        return true
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply { setText(serverUrl); setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("服务器地址")
            .setMessage("默认使用在线版；如已用 Docker/Vercel 自部署，可改为自己的地址。")
            .setView(input)
            .setPositiveButton("保存并打开") { _, _ ->
                var u = input.text.toString().trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_URL, u).apply()
                    webView.loadUrl(u)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
