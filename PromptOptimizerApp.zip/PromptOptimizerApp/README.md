# 提示词优化器 Android APP

用 WebView 承载 https://prompt.always200.com （开源项目 linshenkx/prompt-optimizer），
网页版全部功能都在 APP 里：系统/用户提示词优化、多轮迭代、原始 vs 优化对比测试、
多模型管理（OpenAI / Gemini / DeepSeek / 智谱 / SiliconFlow / 自定义 OpenAI 兼容接口）、
模型参数、图像生成（文生图/图生图）、高级测试（变量、多轮会话、工具调用）、
历史记录、模板管理、数据导入导出、主题与语言等。

## 构建
1. 安装 Android Studio（Koala 或更新），File → Open 选择本文件夹，等待 Gradle 同步。
2. 真机/模拟器直接 Run；打包：Build → Build APK(s)，或 `./gradlew assembleDebug`。
3. 要求 Android 10 (API 29) 及以上。

## 说明
- API 密钥、历史记录保存在 APP 本地，卸载会清除；请先在网页“设置→数据管理”里导出备份。
- 菜单（右上角）可改成自部署地址，或清除缓存（不会清除密钥/历史）。
- WebView 同样受浏览器跨域（CORS）限制：遇到接口跨域报错时，在模型设置里开启“使用 Vercel 代理”，
  或把地址改为自己部署的版本。

## 不装 Android Studio，云端打包 APK
1. 在 GitHub 新建仓库，把本文件夹内容（含 .github 文件夹）全部上传到仓库根目录。
2. 打开仓库 Actions → Build APK → Run workflow，约 3–5 分钟。
3. 完成后在该次运行页面底部 Artifacts 下载 PromptOptimizer-APK（zip，解压得到 app-debug.apk），装到手机即可。
